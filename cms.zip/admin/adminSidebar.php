<div class="sidebar">
    <ul class="sidebar--items">
        <li>
            <a href="adminDashboard.php">
                <span class="icon icon-1"><i class="ri-user-2-line"></i></span>
                <span class="sidebar--item">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="adminUser.php">
                <span class="icon icon-2"><i class="ri-contacts-book-fill"></i></span>
                <span class="sidebar--item">Users</span>
            </a>
        </li>

    </ul>
    <ul class="sidebar--bottom-items">
        <li>
            <a href="adminSetting.php">
                <span class="icon icon-5"><i class="ri-settings-3-line"></i></span>
                <span class="sidebar--item">Settings</span>
            </a>
        </li>
        <li>
            <a href="../include/logOut.php">
                <span class="icon icon-6"><i class="ri-logout-box-r-line"></i></span>
                <span class="sidebar--item">Logout</span>
            </a>
        </li>
    </ul>
</div>