<?php
include 'dbConn.php';
$conn = openConn();
session_start();
