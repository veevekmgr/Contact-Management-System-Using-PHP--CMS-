 <div class="cards">
     <div class="card card-1">
         <div class="card--data">
             <div class="card--content">
                 <h5 class="card--title">Total<br> Contacts</h5>
                 <h1><?php echo $row_count; ?></h1>
             </div>
             <i class="ri-contacts-book-fill card--icon--lg"></i>
         </div>
     </div>
     <div class="card card-2">
         <div class="card--data">
             <div class="card--content">
                 <h5 class="card--title">New<br> Contacts</h5>
                 <h1><?php echo $row_count; ?></h1>
             </div>
             <i class="ri-user-line card--icon--lg"></i>
         </div>
     </div>
 </div>
 <!--Dashboard Cards End-->